# LITEDIRT UI Library

A modular Roblox UI library written in Luau.

## Install

1. In Roblox Studio, create a **ModuleScript** inside `ReplicatedStorage`.
2. Name it `LITEDIRT`.
3. Copy the contents of `src/LITEDIRT.lua` into that ModuleScript.
4. Create a **LocalScript** in `StarterPlayerScripts` or `StarterGui`.
5. Copy the example from `examples/Demo.client.lua` and run the experience.

> This library uses Roblox's normal client UI APIs. It is intended for interfaces in experiences you own or are authorized to develop. Do not use `loadstring` or executor-only APIs.

## API

```lua
local Litedirt = require(game.ReplicatedStorage.LITEDIRT)

local Window = Litedirt:CreateWindow({
    Name = "LITEDIRT",
    Subtitle = "UI Library",
    Size = UDim2.fromOffset(570, 390),
})

local Tab = Window:CreateTab("Main")
Tab:CreateButton({ Name = "Click", Callback = function() print("Clicked") end })
Tab:CreateToggle({ Name = "Enabled", Default = false, Callback = function(value) print(value) end })
Tab:CreateSlider({ Name = "Amount", Min = 0, Max = 100, Default = 50, Callback = function(value) print(value) end })
Tab:CreateDropdown({ Name = "Mode", Options = {"A", "B"}, Default = "A", Callback = function(value) print(value) end })
Tab:CreateTextbox({ Name = "Text", Placeholder = "Type...", Callback = function(value, enterPressed) print(value) end })
Tab:CreateLabel({ Name = "A label" })
Tab:CreateSection("Section title")

Window:Notify({ Title = "Notice", Content = "Hello!", Duration = 3 })
Window:Destroy()
```

## Notes

- All UI creation and input handling should run from a `LocalScript`.
- `Callback` functions are protected with `pcall`; callback errors are sent to Output as warnings.
- The slider reports decimal values; round them in your callback if needed.
- This is an initial v1.0.0 foundation. Test it in Studio and extend it to fit your game's UI requirements.
