-- Put LITEDIRT (ModuleScript) in ReplicatedStorage.
-- Run this from a LocalScript in StarterPlayerScripts or StarterGui.

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Litedirt = require(ReplicatedStorage:WaitForChild("LITEDIRT"))

local Window = Litedirt:CreateWindow({
    Name = "LITEDIRT",
    Subtitle = "My Roblox Experience",
    Size = UDim2.fromOffset(570, 390),
})

local Main = Window:CreateTab("Main")
Main:CreateSection("Getting Started")

Main:CreateButton({
    Name = "Say Hello",
    Callback = function()
        print("Hello from LITEDIRT!")
        Window:Notify({
            Title = "LITEDIRT",
            Content = "Button clicked successfully.",
            Duration = 3,
        })
    end,
})

Main:CreateToggle({
    Name = "Example Toggle",
    Default = false,
    Callback = function(enabled)
        print("Toggle:", enabled)
    end,
})

Main:CreateSlider({
    Name = "Volume",
    Min = 0,
    Max = 100,
    Default = 50,
    Callback = function(value)
        print("Volume:", math.floor(value))
    end,
})

Main:CreateDropdown({
    Name = "Choose Mode",
    Options = { "Easy", "Normal", "Hard" },
    Default = "Normal",
    Callback = function(choice)
        print("Selected:", choice)
    end,
})

Main:CreateTextbox({
    Name = "Player Note",
    Placeholder = "Enter a note...",
    Callback = function(text, enterPressed)
        if enterPressed then
            print("Submitted:", text)
        end
    end,
})

local About = Window:CreateTab("About")
About:CreateLabel({
    Name = "LITEDIRT UI Library v1.0.0",
})

Window:Notify({
    Title = "Welcome",
    Content = "LITEDIRT is ready.",
    Duration = 4,
})
